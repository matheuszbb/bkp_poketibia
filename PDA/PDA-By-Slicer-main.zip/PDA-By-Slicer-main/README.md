<h1 align="center">
    PDA By Slicer
</h1>
<h4 align="center">
  Um servidor antigo de Poketibia iniciado pelo usuário "Brun123" e editado por mim.
</h4>
<p align="center">
  <img alt="Imagem do tópico no fórum do xTibia" src="https://i.imgur.com/3paZ4xR.png">
</p>

## História

Em 2012 eu fiquei meio frustado com um servidor privado de Poketibia chamado [PokeXGames](https://www.pokexgames.com/) e decidi tentar criar um para mim. 

Após ler bastante sobre a criação de servidores de tibia eu acabei me deparando com um servidor postado no fórum [xTibia](https://xtibia.com/forum/portal) que tinha sido criado pelo usuário "Brun123", mas o mesmo tinha parado de dar suporte ao projeto. 

Eu então comecei a ajudar no tópico, corrigindo bugs e criando pequenas melhorias, até que um amigo sugeriu que eu deveria criar um tópico próprio e continuar atualizando o servidor. Com isso, ["PDA By Slicer"](https://xtibia.com/forum/topic/185337-pokemon-pda-by-slicer-1929/) foi criado.

Como eu não conhecia o [Git](https://git-scm.com/) / [Github](https://github.com/) na época, eu acabei simplesmente zipando o código todo, fazendo o upload em um site e postando no fórum, mas como da para imaginar, isso foi gerando problemas com o tempo, ja que muita gente utilizava o meu servidor como base, mas ia adicionando mudanças próprias e ainda assim queria também adicionar as correções de bugs e melhorias que eu programava. Eu então comecei a adicionar comentários em todos os arquivos que eu editava de uma versão para outra, como: `--Edited v1.X.Y`, mas eu nem sempre lembrava também (;p). 

Após um ano atualizando o servidor, levando em conta as sugestões e comentários dos outros usuários do fórum, eu decidi parar de atualizar o servidor e focar na faculdade. 

Foi um ano muito divertido e de muito aprendizado e com certeza foi a razão de eu ser um desenvolvedor de software hoje em dia. Tenho muito a agradecer a todos os usuários do fórum que ajudaram nessa jornada. 
